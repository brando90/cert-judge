# AGENT PROMPT v2 — Implement PTI-v0 and run the bridge experiment (fully specified)

Repository: `github.com/brando90/cert-judge`. Supersedes `agent-prompt-pti-v0-run.md` (v1).

## Authority and conflict handling

Specification precedence: `docs/spec/certjudge-memo-addendum-R23-R35.md` (the addendum) >
`certjudge-revision-memo.md` (the memo) > this prompt > code comments. Implement PTI-v0 exactly
as specified in the memo's frozen definition block **as amended by the addendum**. If anything
appears wrong, unimplementable, or in unresolved conflict, **stop and report** — do not adjust,
do not choose, do not silently fix.

## Hard rules

1. New branch `pti-v0` off `main`. Open a PR at the end; do not merge, do not push to `main`.
2. **Hard Rule 9:** before any run that loads an API key, surface the exact script, the number
   of judge calls, and the estimated cost, and wait for explicit approval. This run is designed
   so the **only** possible spend is the α paired-difference inference (Step 0e); everything
   else must come from cached judge outputs or free computation. If you discover any other
   probe family is not fully cached, that is a second spend decision: surface it the same way
   and wait — never infer approval.
3. Every number that reaches a results file is labeled **DOCUMENTED** (traced to an artifact —
   cite the path), **DERIVED** (computed here — show the command), or **UNKNOWN**. The analytic
   SESOI constants (arcsin values) are labeled **DERIVED-analytic**.
4. Deterministic: fix all seeds (bootstrap seed 0, simulation seed 0); sort every iteration by
   item id; identical inputs must produce bit-identical outputs. Use log-domain GM evaluation
   throughout (memo §7): clip factors to [0,1] before logging; check exact zeros before logging
   and return 0 with the zero itemized; `math.fsum` or NumPy pairwise summation.
5. **R34:** never reuse TI_var-era numbers as PTI-v0 results. Never modify PTI-v0 after any
   bridge number exists. Never drop, reweight, or add properties based on results.

## Step 0 — Ground truth, cache inventory, and the single spend gate

0a. Run `experiments/26_human_label_dataset_audit/audit_human_labels.py` and
    `reconcile_paper_numbers.py` (pure stdlib). Record outputs. If they disagree with memo §4,
    **stop and report** the discrepancy.

0b. **Execute R35 (Option B):** rename the three stale label rows
    (`0_unsafeMultiply_safe` → `1_unsafeMultiply_safe`), re-run both audit scripts, and confirm
    the aligned panel reconciles to **75 = 25 × 3 rated and analyzed**. Commit the rename and
    the fresh audit output. If it does not reconcile, stop and report; do not proceed on 72.

0c. **Judge manifest.** Commit `results/pti_v0/judge_manifest.csv` with columns
    `judge_id, family, role` where `role ∈ {primary, control}` following memo Table-10
    conventions (BAD_STRINGY variants, edit-distance, and random are `control`; prompt-based
    LLM judges are `primary`). The bridge set is the 8-configuration panel; if cached panel
    scores exist for all 13 expanded judges, mark the extra 5 `secondary_panel=true`. This
    manifest is frozen before any property is computed.

0d. **Cache inventory.** Enumerate, per judge × probe family (self-pairs; bug ladders L0–L…;
    spec-removal ladders; α/rename/reorder/style variants scored **against gold**; repeats per
    call), what exists on disk. Commit `results/pti_v0/CACHE_INVENTORY.md` with paths. The
    workshop tensor (|F| = 184, K_aj = 3) should cover eq/bm/ms; confirm rather than assume.
    Include `experiments/27_ti_plot_like_scatter_plots` in the inventory: it holds the
    item-level TI scatter work — per-judge panel scores on the aligned pairs, per-item repeat
    dispersions, possibly cached per-judge criterion values — which Task B consumes and
    Step 4 cross-checks.

0e. **The single spend gate (α paired-difference).** The paired difference needs
    s̃(x, y*, T(ŷ)) for T ∈ {alpha, rename, reorder, style} (α enters PTI-v0; the other three
    are diagnostics per R25). Existing identity-variant runs scored T(ŷ) against ŷ
    (self-pairs), which is a **different quantity** — check the cache for variant-vs-**gold**
    scores specifically. If absent: post the exact script, call count
    (|D_α| × 4 transforms × K_aj × n_judges), and cost estimate; **wait for approval**. Record
    the outcome in `RESULTS.md` as `ALPHA_RUN: funded | declined | partial(scope)` **before any
    bridge number is computed** (R23). Declined → the headline is PTI_{eq,bm,ms}, so labeled;
    P_eqα = NOT RUN.

## Step 1 — Probe sets from one frozen base pool

Freeze the base pool and commit its manifest (file list + commit hash) before generating
anything. Four separate sets, never merged:

| Set | Construction | Used by |
|---|---|---|
| `D_eq` | self-pairs of **base** artifacts, candidate vs itself (R31) | file equality |
| `D_bm` | cumulative bug ladders, L0 clean … L_max | bug monotonicity |
| `D_ms` | cumulative specification-removal ladders, L0 … L_max | missing-spec monotonicity |
| `D_alpha` | (candidate, T_α(candidate)) with gold fixed | α semantic equivalence |

Record |D_k| for each. Reuse existing scripted ladders/variants wherever cached; regeneration
of probes is free (no API) but must be deterministic and committed.

## Step 2 — PTI-v0, exactly

Scores normalized to [0,1] first; s̃ = **median** over repeats.

```
# Ladder properties (T ∈ {bm, ms}), per item y:
rho_y    = Spearman(level index ℓ, s̃ at ℓ)          # over the ladder's rungs
C_y      = clip((1 - rho_y) / 2, 0, 1)               # (1+rho)/2 wherever positive
                                                     # association is desired; never |rho|,
                                                     # never R^2, never CCC/ICC here
sigma_r  = population std (ddof=0) of the K_aj repeat scores at rung r      # R24
sig_r    = min(1, 2 * sigma_r)
sigma_y  = arithmetic mean of sig_r over rungs        # R24
mu_VS_y  = sqrt( C_y * (1 - sigma_y) )               # exponent = 1/(factors present)

# Equality properties, per item y:
V_eq_y   = s̃(x, y, y)                               # self-pair, base pool
V_eqa_y  = 1 - | s̃(x, y*, ŷ) - s̃(x, y*, T_alpha(ŷ)) |    # R25 paired difference

# Aggregation (two-level GM, log domain, no floor — R29):
P_eq     = GM over D_eq    of V_eq_y
P_bm     = GM over D_bm    of mu_VS_y
P_ms     = GM over D_ms    of mu_VS_y
P_eqa    = GM over D_alpha of V_eqa_y
PTI_v0   = (P_eq * P_bm * P_ms * P_eqa) ** (1/4)     # R23; also emit PTI_{eq,bm,ms}
```

Degenerate ladders (R26), in order: (i) **panel cleaning** — items constant under every
primary are removed from that D_T for all judges; commit the removed list; the cleaned set is
frozen for future screening; (ii) **per-judge exclusion** of remaining constant ladders, with
excluded fraction recorded; (iii) excluded fraction > **0.20** ⇒ that property **NOT
COMPUTABLE** for that judge ⇒ PTI-v0 undefined for that judge (dropped from the bridge, drop
reported; screen outcome DEFER, never PASS). Never assign 0 to a degenerate ladder; never
impute.

Emit `results/pti_v0/property_table.csv`: one row per judge —
`judge_id, family, role, P_eq, P_bm, P_ms, P_eqa, PTI_v0, PTI_eq_bm_ms, excl_frac_bm,
excl_frac_ms, zeros_eq, zeros_bm, zeros_ms, zeros_eqa, |D_eq|, |D_bm|, |D_ms|, |D_alpha|,
not_computable_flags` — plus three **labeled sensitivity columns**: raw-std variant (R24),
ε = 1e-3-floored variant (R29, only meaningful if zeros occurred), and C = 1/2-assigned
variant for judge-specific degenerate ladders (R26.5). Sensitivities never replace headline
values.

## Step 3 — Property table, gates, and the pre-bridge commit

Commit the property table, probe manifests, cleaning lists, and a `GATES.md` **in a commit that
precedes any bridge computation** (R33 — the git history is the pre-registration evidence).
`GATES.md` reports:

- **HARD gates (any failure ⇒ stop before the bridge, report, await instruction):** a property
  NOT COMPUTABLE for > 50% of primaries; panel cleaning removed > 20% of any probe set;
  coverage/schema failure; Step-0a/0b audit mismatch.
- **SOFT flags (proceed; report prominently):** any control's PTI ≥ any primary's; any property
  with range < 0.01 across all judges; PTI range across primaries < 0.05; P_eq range across
  primaries < 0.05 (R31 flatness — if flagged, the paper's P_eq framing switches to
  "satisfied gate").

## Step 4 — The bridge (only after the Step-3 commit)

```
TI_m1(judge; view) = Spearman over the 75 aligned items of
                     (median-over-repeats judge score, human label under view)
                     for view in {avg (primary), strict, lenient}          # R30, R35
rho_bridge(view)   = Spearman over judges of (PTI_v0, TI_m1)
```

Report, per view, with avg as headline:

- `rho_bridge` **twice — primaries only (lead) and pooled with controls** — each with a seeded
  10,000-iteration bootstrap 95% CI resampling **judges**; Kendall τ_b alongside; `n_judges`
  stated on every figure and table.
- Per-judge TI_m1 with a 10,000-iteration bootstrap CI resampling **items** (seeded).
- The same two-way reporting for the secondary index PTI_{eq,bm,ms} and, as exploratory
  diagnostics only, each single property vs TI_m1.
- If the 13-judge secondary panel exists (Step 0c), the same table at n = 13, labeled secondary.
- Cross-check the freshly computed per-judge TI_m1 values against any cached per-judge
  criterion values in `experiments/27_ti_plot_like_scatter_plots`. Differences are
  **expected** — that experiment predates the Option-B rename (72 vs 75 rows) and may compute
  the TI_2' decomposition (ρ·(1−σ))^{1/2} rather than plain TI_m1 — but every discrepancy is
  explained in RESULTS.md with paths, never silently resolved in either direction.
- The collinearity diagnostic Corr(σ_target-side-free check): report
  Corr(judge repeat-std on the panel, mean σ_y from the properties) once, per memo Config-B
  note.

Everything is a **validation-set number** and is labeled as such in every artifact.

## Step 5 — SESOI simulation (free, numpy, seeded)

On the empirical TI_m1 (avg) values of the bridge judges: simulate (a) the median-gate
false-pass rate and (b) the top-1 selection retention as functions of an induced proxy-target
rank correlation ρ ∈ {0.1, …, 0.9}, 10,000 draws per point, seed 0. Report beside the analytic
anchors (P(low|pass) = 1/2 − arcsin(ρ)/π; retention ≈ ρ), all labeled DERIVED /
DERIVED-analytic. This replaces the bivariate-normal approximation with panel-specific numbers
for the paper's SESOI paragraph (R28).

## What not to do

- Do not modify PTI-v0 after seeing any bridge number; do not reselect properties or weights.
- Do not impute or interpolate missing probe results; report coverage.
- Do not fit a calibration model mapping PTI to TI at this judge count.
- Do not merge, do not push to `main`, do not submit anything anywhere.

## Deliverables (all on branch `pti-v0`)

1. Metric module with docstring naming PTI-v0 and citing the memo §1 frozen block + addendum
   rulings; tests covering: ddof-0 bound (2·std ≤ 1), clip-before-log, zero short-circuit,
   degenerate-ladder exclusion vs cleaning, determinism (same seed ⇒ identical CSVs).
2. `judge_manifest.csv`, `CACHE_INVENTORY.md`, probe manifests, cleaning lists,
   `property_table.csv`, `GATES.md` (Step-3 commit), bridge results CSVs (Step-4 commit),
   SESOI simulation CSV.
3. `RESULTS.md`: what ran, what it cost, the ALPHA_RUN record, every number labeled, HARD/SOFT
   gate outcomes, and an explicit list of anything that surprised you.
4. Numerics note for the paper appendix per memo §7: the log-domain identity, the underflow
   argument, zero handling under R29, observed zero counts.
5. PR from `pti-v0` with the Step-3 and Step-4 commits clearly separated in history.

---
END OF AGENT INSTRUCTIONS

```
TL;DR (for the human reader; the agent should ignore this block):
This is v1's experiment runner with every open knob pinned by the addendum: Option B
(panel = 75) executed first, judge roles frozen in a manifest, cache inventoried, and
exactly one possible spend — the α-vs-gold inference — surfaced with script+cost under
Hard Rule 9 and recorded as funded/declined BEFORE any bridge number exists (declined ⇒
labeled 3-property headline). The metric is implemented exactly (2·std_pop ddof=0
averaged over rungs, median repeats, log-domain GM, no floor, panel cleaning then
per-judge exclusion with θ=0.20, NOT COMPUTABLE ⇒ dropped from bridge and never
screen-PASS). The old human stop between property table and bridge is replaced by
automated hard/soft gates with the property table committed in a separate prior commit,
so the run goes end-to-end unless something is actually wrong. Bridge = PTI-v0 vs TI_m1
on avg labels, primaries-only lead + pooled, bootstrap CIs, τ_b, per-property
exploratory, plus a free SESOI simulation on the real panel.
```
