# README v3 — Launch instructions (for Brando, not for the agent)

Final merged package: Claude protocol layer + ChatGPT Pro numerics layer, conflicts
adjudicated. Supersedes the v2 and v3 zips.

## Launch (3 steps)
1. Open Claude Code in `cert-judge`; add ALL files from this zip to the session.
2. **Also add, from ChatGPT's package (not uploaded here, so not in this zip):**
   `pti_v0_reference_final.py` (the oracle — most important), `DECISION_LOG.md`,
   `PTI_V0_PAPER_READY_METHOD.tex`, `PTI_V0_PAPER_READY_NARRATIVE.tex`,
   `PTI_V0_NUMERICAL_STABILITY_APPENDIX.tex`, `PTI_V0_IMPLEMENTATION_MEMO.md`,
   `SOURCE_PROVENANCE.md`. The pipeline degrades gracefully without them (the oracle is
   re-implemented from spec + vectors), but including them saves work and risk.
3. Paste the contents of `00-CC-MASTER-PROMPT-v3.md` as the message.

## The one mid-run pause
The α-vs-gold inference cost (script + call count + $) under Hard Rule 9. Reply funded or
declined; declined ⇒ pre-declared labeled 3-property headline.

## Key adjudications (veto before pasting if wrong)
- ChatGPT's constant-ladder C=0 policy is REPLACED by exclusion + panel cleaning + θ=0.20
  (their policy + no-floor GM would zero every judge's PTI on one saturated probe item).
- Their absolute no-paid-calls rule gains exactly one gate (the α run) — otherwise P_eqα
  can never be computed and "run the experiments fully" is impossible.
- Manuscript task auto-detects `paper_latex/ICLR_2027_submission/main.tex`; if present
  (as ChatGPT observed), it revises in place and keeps the in-repo "Proxy Gap" title
  (vs memo shortlist "Surrogate Gap" — flagged in OPEN_QUESTIONS for you).
- `experiments/27_ti_plot_like_scatter_plots` is explicitly anchored: Task B revises its
  item-level figures in place and mines it for real per-judge data; Task A inventories it
  and cross-checks the new TI_m1 values against its cached criterion values (expected
  deltas from the 72->75 rename and TI_2'-vs-TI_m1 are pre-explained in the prompts).
- Everything ratified earlier stands: R23 four-property headline vs TI_m1, R35 Option B
  (panel = 75), R33 automated gates, avg primary label view, SESOI 0.5, two-way
  primaries/pooled reporting.

## After kickoff
Approve/decline α → review 3 PRs → OpenReview: abstract Sep 18, paper Sep 25 AoE →
register the reciprocal reviewer (new ICLR requirement).
