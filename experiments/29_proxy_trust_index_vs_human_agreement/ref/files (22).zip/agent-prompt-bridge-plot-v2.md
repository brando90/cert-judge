# AGENT PROMPT v2 — PTI ↔ TI bridge calibration figure (corrected axes and names)

Repository: `github.com/brando90/cert-judge`. Supersedes `agent-prompt-bridge-plot.md` (v1).
Authority: addendum > memo > this prompt; stop and report on substantive conflict.

## Goal

A reusable plotting utility visualizing the central empirical claim: the label-free proxy
**PTI-v0** tracks the human-grounded criterion **TI_m1** across judge configurations. One point
per judge. This is the paper's Figure 1 candidate.

Axis semantics (R23/R32 — these correct v1):

- **x-axis (proxy):** PTI-v0(aj) = (P_eq · P_bm · P_ms · P_eqα)^{1/4}, computed label-free on
  the full benchmark b. If the run's ALPHA_RUN record is `declined`, x is PTI_{eq,bm,ms} and
  every title/label says so.
- **y-axis (criterion/target):** **TI_m1(aj)** = Spearman over the 75 aligned items of (judge
  score, human label), per label view. **Not TI_2'** — under Config B, a (1−std) factor on the
  y-axis would put repeat-stability on both sides of the bridge and make part of the
  correlation mechanical. TI_2' survives only in the item-level diagnostic figure's legend
  decomposition (below).
- Property names in code and labels: `P_eq, P_bm, P_ms, P_eqa`. The v1 names `P_rfl, P_mb,
  P_mms, P_alphaSI` are banned.
- Note for axis limits: PTI-v0 lives in [0,1]; TI_m1 is a Spearman in [−1,1]. Fix the y-axis to
  [−1, 1] with a light rule at 0 (do not clip negative criterion values — a control below zero
  is information), and the x-axis to [0,1]. The y=x diagonal is therefore drawn only over
  [0,1]×[0,1] and labeled "level agreement (reference)".

## Anchor to the existing experiment

The item-level TI scatter work already exists in-repo at
`experiments/27_ti_plot_like_scatter_plots`. Read it before writing any code:

- The item-level diagnostic figure below is a **revision of that experiment's existing
  figures and code**, not a rewrite — apply the revision notes to its actual structure, keep
  its data-loading paths, and follow its conventions.
- Mine it for real inputs: per-judge panel scores on the aligned pairs, per-item repeat
  standard deviations, any cached per-judge criterion values/CIs. Prefer those real values
  over the synthetic generator wherever they exist, and state in the PR which values came
  from 27 (with paths).
- The two v1 diagnostics (is the plotted std the repeat std rather than the across-item std?
  why does the random control report σ = 0.00?) are answered by reading 27's code, read-only.
- The new outer bridge figure follows the repo's experiment convention: extend 27 if its
  structure invites it, otherwise create the next-numbered sibling directory (e.g.
  `experiments/28_bridge_plot`) matching observed conventions — never an orphan module.
- If the directory is absent or renamed, locate the item-level TI scatter experiment via the
  Task-A repository audit and report the actual path; do not guess.

## Hard rules

1. Branch `bridge-plot` **off the head of `pti-v0`** (it consumes that run's CSVs). PR; no
   merge; no push to `main`.
2. **No API-key-loading runs and no judge inference.** Consume `results/pti_v0/*.csv` only, or
   the synthetic generator. If real per-judge values are absent, build against synthetic data
   and say so in the PR — never invent plausible numbers.
3. Deterministic: seeded bootstrap/jitter; identical inputs ⇒ byte-identical figures.
4. Pure matplotlib + numpy + pandas (+ scipy if already a dependency). No new dependencies
   without asking.

## Data contract (tidy schema, validated on load)

| column | type | meaning |
|---|---|---|
| `judge_id` | str | e.g. `gpt5.3-codex-P8_STRICT_B` |
| `family` | str | `codex` / `opus` / `qwen` / `gpt-4o-mini` / `non-llm` |
| `role` | enum | `primary` \| `control` \| `anchor` |
| `pti` | float [0,1] | PTI-v0 (or labeled 3-property fallback) |
| `pti_lo`, `pti_hi` | float | bootstrap CI over probe items (nullable) |
| `ti` | float [−1,1] | TI_m1 for the active label view |
| `ti_lo`, `ti_hi` | float | bootstrap CI over the 75 items (nullable) |
| `label_view` | enum | `strict` \| `lenient` \| `avg` |
| `not_computable` | bool | any property NOT COMPUTABLE (R26) |

Judges with `not_computable = true` have no defined PTI: render them as tick marks in a thin
side gutter at their `ti` value, labeled "NOT COMPUTABLE (n=…)", excluded from all statistics,
with the count in the stats box. Never silently drop them. `role = anchor` covers the
uniform-random reference and a known-good reference judge. Ship `make_synthetic_bridge_frame
(seed)` producing ≈ 10 primaries across 3 families, 3 controls, 2 anchors, 1 not-computable,
for end-to-end development without real numbers.

## Stage 1 — two plain figures first

- **Fig A `bridge_scatter`**: `pti` on x, `ti` on y, one marker per judge, axes per the limits
  above, y=x reference over the unit square, judges labeled.
- **Fig B `bridge_marginals`**: 1-D marginal distributions (histogram; KDE only if scipy
  present) of `pti` and `ti`.

## Stage 2 — the merged figure

Joint plot: central scatter, marginal panels top (pti) and right (ti), shared axes. Required:

1. **Error bars on both axes** wherever CIs exist; with ~10 judges the uncertainty is the
   story. Judges missing CIs are plotted without whiskers and counted in the stats box.
2. **y = x reference** over [0,1]² only, dashed, labeled as level agreement — stronger than the
   rank agreement the bridge claims.
3. **Fit line with bootstrap band** (resample judges, primaries only), labeled explicitly as a
   visual guide, not a model. Never extrapolated beyond the observed x-range.
4. **Markers by role** (filled primary, hollow control, starred anchor); color by family;
   colorblind-safe; encoding must survive grayscale (shape, not just hue).
5. **Statistics box**, per active label view: `n_judges` (primaries; total); Spearman ρ
   **twice — primaries only, and pooled with controls — with seeded bootstrap 95% CIs**;
   Kendall τ_b both ways; Pearson r both ways; mean |PTI − TI| over primaries (level gap,
   computed only where ti ≥ 0 and noted as such); count of not-computable and missing-CI
   judges. The two-way reporting is mandatory: controls span most of the range and can carry a
   pooled correlation alone. Never display only the flattering number.
6. **Anchor annotations** ("uniform-random judge", "reference good judge") placed to avoid
   data overlap.
7. `label_view` parameter regenerating the figure for strict / lenient / avg (avg is the
   default and the paper's primary view, R30), plus `panel=True` for all three side by side.

## API

```python
plot_bridge(
    df,                      # tidy frame per the schema above
    label_view="avg",
    show_controls=True,
    show_diagonal=True,
    show_fit=True,
    annotate="anchors",      # "none" | "anchors" | "all"
    out=None,                # path stem; writes .pdf and .png at 300 dpi
    seed=0,
) -> matplotlib.figure.Figure
```

Place it where the repo's plotting helpers already live; return the figure; write files only
when `out` is given.

## Deliverables

1. The plotting module, docstring stating axis semantics (proxy on b vs criterion on b'; the
   unit of observation is the judge configuration) and the TI_m1-not-TI_2' rule with one-line
   rationale.
2. `make_synthetic_bridge_frame(seed)`.
3. Tests: schema validation rejects out-of-range values and unknown roles; headless build (Agg)
   for all three views and `panel=True`; identical seeds ⇒ identical summary statistics;
   not-computable judges appear in the gutter and not in the statistics.
4. README section with the call and the synthetic example figure.
5. PR description: the synthetic-data figure, plus an explicit statement of whether real
   per-judge values were found (with paths) or everything shown is synthetic.

## The item-level (per-judge) diagnostic figure — revision notes retained from v1

These revisions apply to the existing figures in `experiments/27_ti_plot_like_scatter_plots`.
Keep the per-judge item-level figure (human score vs judge repeat-mean over the 75 panel items)
with the v1 second-pass revisions, updated for final semantics:

- The legend's decomposition (ρ·(1−σ))^{1/2} is the **deployment criterion TI_2'** and must be
  labeled as such — it is a per-judge diagnostic, never the bridge's y-value. Show ρ with a
  bootstrap CI, Kendall τ_b, and n; state which correlation the composite uses.
- No 2-D density shading (lattice data; decorative smoothing banned). Count-sized lattice dots
  or hexbin in the center; 1-D marginals top/right (they are the m0 diagnostic showing range
  restriction and the calibration gap).
- Per-point vertical error bar = that item's **repeat standard deviation** (judge
  self-consistency at fixed item) — name the exact quantity in the caption; it is the only
  representation of the stability conjunct in the figure.
- Either drop y = x or add a rank(human)-vs-rank(judge) companion panel where it is meaningful.
- Optional labeled calibration-gap number (TV or 1-D Wasserstein between the marginals),
  clearly a separate diagnostic from alignment.
- Verify on a **real** judge, not the random control, and report the two v1 diagnostics:
  (i) confirm the plotted std is the repeat std, not the across-item std; (ii) explain the
  random control's σ = 0.00 (deterministic per-item seeding?) and whether that is by design —
  if not by design, note it; do not change the control mid-analysis.

## Optional second deliverable — the inner (per-file) ladder scatter

`plot_ladder_scatter(df_y)`: judge score vs ladder level for one file, plus a small-multiples
grid per judge, same styling. Docstrings must state the two levels explicitly — inner plots are
indexed by items, the bridge by judge configurations.

## What not to do

- No calibration model mapping PTI to TI at this judge count; no extrapolated fits.
- No silent dropping of judges (missing CIs plotted bare; not-computable in the gutter; both
  counted).
- No axis tuning to strengthen the trend; limits are fixed as specified.

---
END OF AGENT INSTRUCTIONS

```
TL;DR (for the human reader; the agent should ignore this block):
Same figure as v1 with the two errors fixed: the y-axis is now TI_m1 (plain human
Spearman — v1's TI_2' would have put repeat-stability on both sides of the bridge and
manufactured correlation), and the y-range is [−1,1] so negative controls stay visible;
property names updated to eq/bm/ms/eqα; x is PTI-v0 with an automatic relabel if the α
run was declined. NOT COMPUTABLE judges render in a side gutter instead of vanishing.
Everything else you liked survives: marginals, both-axis error bars, the two-way
(primaries vs pooled) statistics box, anchors, the item-level diagnostic figure with
its repeat-std bars, and the no-inference/no-spend rule.
```
