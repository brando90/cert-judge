# Anonymous score-level reproduction supplement

**TLDR:** This package reproduces five current manuscript figures, fixed-index associations, and local weight-sensitivity summaries from frozen numerical artifacts, without model calls or network access. It is not the full research repository and does not rerun inference or recover missing experimental evidence.

## Reproduction

Requires Python 3.11 or newer. The dependencies are pinned to the versions used to verify this package.
From this extracted directory, create an isolated environment and install dependencies with `uv venv .venv` and `uv pip install --python .venv/bin/python -r requirements.txt`.
Then run:

```sh
.venv/bin/python experiments/34_iclr_mega_rewrite_astra/analysis/rebuild_paper_evidence.py
```

The calculation makes no network requests, reads no credentials, and requires no Git installation or history.
It checks all 28 input files against `input_manifest.json` before use.
Outputs are written to `experiments/34_iclr_mega_rewrite_astra/analysis/results/` and `paper_latex/ICLR_2027_submission/figures/` within this extracted package.
The package includes verified outputs in these locations for inspection without installing dependencies.

## Included coverage

- Fixed equal-weight index recomputation from the three recorded component columns for all three primary families and all three human-label views; eight configurations per family/view.
- Spearman, Pearson, and Kendall associations with recorded judge-level human agreement, and the 12-point local weight grid for each family/view.
- Frozen summaries for the arithmetic and pass1-selected geometric comparisons; their reported correlations are copied from those summaries rather than reconstructed from original human labels.
- Frozen Codex confidence-interval and permutation summaries with their recorded seed and repetition counts; the resampling procedure itself is not rerun here.
- Codex recorded repeated scores, bug-level averages, rewrite diagnostics, and local reversal counts; Claude Opus recorded repeated scores and bug-level averages.
- Five regenerated figures: `judge_agreement_fixed_index.pdf`, `codex_property_checks.pdf`, `codex_rewrite_diagnostics.pdf`, `codex_reversal_counts.pdf`, and `opus_bug_curves.pdf`.
- Exact current main-panel prompt text and documented model identifiers/repetition settings in `PROMPTS_AND_MODELS.tex`, matching the manuscript appendix. Missing historical decoding settings are not inferred.

Historical directory names are retained so paths in the manuscript remain traceable.
All 28 inputs preserve their source bytes except one absolute machine path in a nonnumeric `source_summary` field, replaced with its relative package path.
Numerical observations and configuration identifiers are unchanged.
No author names, repository URLs, machine paths, Git history, logs, private correspondence, or credentials are intentionally included.
`file_manifest.json` hashes every payload file except itself; `input_manifest.json` specifies the frozen numerical input set.

## Limitations

This is score-level reproduction, not a complete end-to-end rerun from Lean candidates and original human labels.
It does not contain the original human annotation instructions (which were not recovered), all task/gold/candidate files, raw model response text, inference clients, or every historical appendix experiment.
It does not regenerate the confidence-interval bootstrap, the different-rubric pool analyses, the threshold sweep, or the separate cross-pass fitted-weight experiments.
The supplied confidence summaries and comparison results are explicitly stored evidence, not fresh experimental runs.
The three label views are validation views of the same panel, not train/validation/test splits; there is no test-set result.
The historical alpha-rewrite probes were not established to preserve meaning, and the main panel contains no missing-specification ladder measurements.
Reproducing these descriptive numerical artifacts does not resolve those limitations.
